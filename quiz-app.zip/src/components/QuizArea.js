import React from "react";
import Questions from "./Question";
import AnswerList from "./AnswerList";
import UserGreeting from "./UserGreeting";
import Pass from "./Pass";
import Fail from "./Fail";
function QuizArea(props) {
  if (props.isFinished) {
    if (props.success) {
      return (
        <div>
          <UserGreeting />,<Pass />
        </div>
      );
    } else if (props.unsuccess) {
      return (
        <div>
          <UserGreeting />,<Fail />
        </div>
      );
    }
  }

  return (
    <div>
      <Questions dataSet={props.dataSet} />
      <AnswerList handleClick={props.handleClick} dataSet={props.dataSet} />
    </div>
  );
}

export default QuizArea;
