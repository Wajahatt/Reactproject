import React from "react";

function Fail(props) {
  return (
    <div>
      <h1 className="fail">Fail &#128531;</h1>
    </div>
  );
}

export default Fail;
