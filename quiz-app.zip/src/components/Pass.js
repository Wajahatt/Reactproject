import React from "react";

function Pass(props) {
  return (
    <div>
      <h1 className="pass">Pass &#127774;</h1>
    </div>
  );
}

export default Pass;
