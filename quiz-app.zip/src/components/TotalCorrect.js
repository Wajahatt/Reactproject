import React from "react";

function TotalCorrect(props) {
  return <h3 className="correct">Correct: {props.correct}</h3>;
}

export default TotalCorrect;
