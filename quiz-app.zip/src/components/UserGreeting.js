import React from "react";

function UserGreeting(props) {
  return (
    <div>
      <h2 className="usergreeating">
        Thank you for Completing the Questionnaire!
      </h2>
    </div>
  );
}

export default UserGreeting;
